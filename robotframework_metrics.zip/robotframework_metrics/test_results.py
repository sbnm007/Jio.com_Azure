from robot.api import ResultVisitor


class TestResults(ResultVisitor):
    

    def __init__(self, test_list):
        self.test_list = test_list
    
    
    def visit_test(self, test):

        a = 0
        if test.tags:
            if test.tags[0].isdigit():
                a =  int(test.tags[0])
            else:
                a = 1
        
        test_json = {
            # "Suite Name" : test.parent,
            "Test Name" : test,
            "Test Id" : test.id,
            "Status" : test.status,
            "Time" : test.elapsedtime,
            "Message" : test.message,
            "Tags" : test.tags[1:],
            "Merged_count" : a

        }
        self.test_list.append(test_json)