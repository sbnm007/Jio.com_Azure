import math
from robot.api import ResultVisitor


class SuiteResults(ResultVisitor):

    def __init__(self, subModule_list,module_list):
        self.subModule_list = subModule_list
        self.module_list = module_list
    
    def error_handling(self,module_passed,module_total,module_skipped):
        if module_total == module_skipped:
            a = 0.0
        else:
            a = round(module_passed/(module_total - module_skipped)*100,2)
        return a

    def start_suite(self, suite):
        if suite.tests:
            sm_total_tests = 0
            sm_total_passed = 0
            sm_total_skipped = 0
            sm_total_failed = 0
            
            try:
                sm_stats = suite.statistics.all
            except:
                sm_stats = suite.statistics
            try:
                sm_skipped = sm_stats.skipped
            except:
                sm_skipped = 0

            for test in suite.tests:
                if test.tags:
                    if test.tags[0].isdigit():
                        sm_total_tests = sm_total_tests + int(test.tags[0])
                        if test.status == "PASS":
                            sm_total_passed = sm_total_passed + int(test.tags[0])
                        if test.status == "FAIL":
                            num_keywords = sum(1 for kw in test.keywords)
                            num_failed_keywords = sum(1 for kw in test.keywords if kw.status == 'FAIL')
                            num_passed_keywords = sum(1 for kw in test.keywords if kw.status == 'PASS')
                            num_not_run_keywords = num_keywords - (num_failed_keywords + num_passed_keywords)
                            pass_percentage=round(((num_passed_keywords)/(num_keywords))*100,2)
                            fail_percentage=round(((num_failed_keywords+num_not_run_keywords)/num_keywords)*100,2)
                            
                            

                            passed = (int(test.tags[0]) * pass_percentage)/100
                            failed = (int(test.tags[0]) * fail_percentage)/100

                            sm_total_passed = sm_total_passed + math.ceil(passed)
                            sm_total_failed = sm_total_failed + math.floor(failed)

                        if test.status == "SKIP":
                            sm_total_skipped = sm_total_skipped + int(test.tags[0])            
                    else:
                        sm_total_tests += 1
                        if test.status == "PASS":
                            sm_total_passed += 1
                        if test.status == "FAIL":
                            sm_total_failed += 1
                        if test.status == "SKIP":
                            sm_total_skipped += 1
                else:
                    sm_total_tests += 1
                    if test.status == "PASS":
                        sm_total_passed += 1
                    if test.status == "FAIL":
                        sm_total_failed += 1
                    if test.status == "SKIP":
                        sm_total_skipped += 1
            
            ratio = self.error_handling(sm_total_passed,sm_total_tests,sm_total_skipped)
            submodule_json = {
                "Name" : suite.name,
                "Id" : suite.id,
                "Status" : suite.status,
                "Total" : sm_stats.total,
                "Pass" : sm_stats.passed,
                "Fail" : sm_stats.failed,
                "Skip" : sm_skipped,
                "Time" : suite.elapsedtime,
                "Ratio" : ratio,
                "Devops_total" : sm_total_tests,
                "Devops_passed" : sm_total_passed,
                "Devops_failed" : sm_total_failed,
                "Devops_skipped" : sm_total_skipped,
            }
            if suite.parent:
                submodule_json = {
                "Name" : suite.name,
                "Id" : suite.id,
                "Status" : suite.status,
                "Total" : sm_stats.total,
                "Pass" : sm_stats.passed,
                "Fail" : sm_stats.failed,
                "Skip" : sm_skipped,
                "Time" : suite.elapsedtime,
                "Parent" : suite.parent.name,
                "Ratio" : ratio,
                "Devops_total" : sm_total_tests,
                "Devops_passed" : sm_total_passed,
                "Devops_failed" : sm_total_failed,
                "Devops_skipped" : sm_total_skipped,
            }
                
                self.subModule_list.append(submodule_json)
            else:
                self.module_list.append(submodule_json)
        
        elif suite.suites[0].tests:
                
                m_total_skipped = 0
                m_total_failed = 0
                m_total_passed = 0
                m_total_tests = 0

                
                try:
                    m_stats = suite.statistics.all
                except:
                    m_stats = suite.statistics
            
                try:
                    m_skipped = m_stats.skipped
                except:
                    m_skipped = 0

                for suites in suite.suites:
                    sm_total_tests = 0
                    sm_total_passed = 0
                    sm_total_skipped = 0
                    sm_total_failed = 0

                    
                    for test in suites.tests:
                        if test.tags:
                            if test.tags[0].isdigit():
                                sm_total_tests = sm_total_tests + int(test.tags[0])
                                if test.status == "PASS":
                                    sm_total_passed = sm_total_passed + int(test.tags[0])
                                if test.status == "FAIL":
                                    num_keywords = sum(1 for kw in test.keywords)
                                    num_failed_keywords = sum(1 for kw in test.keywords if kw.status == 'FAIL')
                                    num_passed_keywords = sum(1 for kw in test.keywords if kw.status == 'PASS')
                                    num_not_run_keywords = num_keywords - (num_failed_keywords + num_passed_keywords)
                                    
                                    pass_percentage=round(((num_passed_keywords)/(num_keywords))*100,2)
                                    fail_percentage=round(((num_failed_keywords+num_not_run_keywords)/num_keywords)*100,2)
                                    
                                    

                                    passed = (int(test.tags[0]) * pass_percentage)/100
                                    failed = (int(test.tags[0]) * fail_percentage)/100

                                    sm_total_passed = sm_total_passed + math.ceil(passed)
                                    sm_total_failed = sm_total_failed + math.floor(failed)

                                if test.status == "SKIP":
                                    sm_total_skipped = sm_total_skipped + int(test.tags[0])            
                            else:
                                sm_total_tests += 1
                                if test.status == "PASS":
                                    sm_total_passed += 1
                                if test.status == "FAIL":
                                    sm_total_failed += 1
                                if test.status == "SKIP":
                                    sm_total_skipped += 1
                        else:
                            sm_total_tests += 1
                            if test.status == "PASS":
                                sm_total_passed += 1
                            if test.status == "FAIL":
                                sm_total_failed += 1
                            if test.status == "SKIP":
                                sm_total_skipped += 1

                    m_total_tests = m_total_tests + sm_total_tests
                    m_total_passed = m_total_passed + sm_total_passed
                    m_total_failed = m_total_failed + sm_total_failed
                    m_total_skipped = m_total_skipped + sm_total_skipped

                ratio = self.error_handling(m_total_passed,m_total_tests,m_total_skipped)
                module_json = {
                    "Name" : suite.name,
                    "Id" : suite.id,
                    "Status" : suite.status,
                    "Total" : m_stats.total,
                    "Pass" : m_stats.passed,
                    "Fail" : m_stats.failed,
                    "Skip" : m_skipped,
                    "Time" : suite.elapsedtime,
                    "Ratio" : ratio,
                    "Devops_total" : m_total_tests,
                    "Devops_passed" : m_total_passed,
                    "Devops_failed" : m_total_failed,
                    "Devops_skipped" : m_total_skipped,

                }
                self.module_list.append(module_json)