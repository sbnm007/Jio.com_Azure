import pandas as pd


class Dashboard:

    def __init__(self):
        pass

    @classmethod
    def get_suite_statistics(self, suite_list):
        suite_data_frame = pd.DataFrame.from_records(suite_list)
        if not suite_data_frame.empty:
            suite_stats = {
                "Total" : (suite_data_frame.Name).count(),
                "Pass"  : (suite_data_frame.Status == 'PASS').sum(),
                "Fail"  : (suite_data_frame.Status == 'FAIL').sum(),
                "Skip"  : (suite_data_frame.Status == 'SKIP').sum(),
                "Time"  : (suite_data_frame.Time).sum(),
                "Min"  : (suite_data_frame.Time).min(),
                "Max"  : (suite_data_frame.Time).max(),
                "Avg"  : (suite_data_frame.Time).mean(),
            }
            return suite_stats
    
    @classmethod
    def get_module_statistics(self, module_list):
        module_data_frame = pd.DataFrame.from_records(module_list)
        module_stats = {
            "Total" : (module_data_frame.Name).count(),
            "Pass"  : (module_data_frame.Status == 'PASS').sum(),
            "Fail"  : (module_data_frame.Status == 'FAIL').sum(),
            "Skip"  : (module_data_frame.Status == 'SKIP').sum(),
            "Time"  : (module_data_frame.Time).sum(),
            "Min"  : (module_data_frame.Time).min(),
            "Max"  : (module_data_frame.Time).max(),
            "Avg"  : (module_data_frame.Time).mean()
        }
        return module_stats
    
    @classmethod
    def get_test_statistics(self, test_list,module_list):
        test_data_frame = pd.DataFrame.from_records(test_list)
        module_data_frame = pd.DataFrame.from_records(module_list)
        test_data_frame.loc[test_data_frame['Status'] == "PASS",'Devops_passed'] = test_data_frame['Merged_count']
        test_data_frame.loc[test_data_frame['Status'] == "FAIL",'Devops_failed'] = test_data_frame['Merged_count']
        test_data_frame.loc[test_data_frame['Status'] == "SKIP",'Devops_skipped'] = test_data_frame['Merged_count']
        test_stats = {
            "Total" : (test_data_frame.Status).count(),
            "Pass"  : (test_data_frame.Status == 'PASS').sum(),
            "Fail"  : (test_data_frame.Status == 'FAIL').sum(),
            "Skip"  : (test_data_frame.Status == 'SKIP').sum(),
            "Time"  : (test_data_frame.Time).sum(),
            "Min"  : (test_data_frame.Time).min(),
            "Max"  : (test_data_frame.Time).max(),
            "Avg"  : (test_data_frame.Time).mean(),
            "Devops_total": (module_data_frame.Devops_total).sum(),
            "Devops_passed": int((module_data_frame.Devops_passed).sum()),
            "Devops_failed": int((module_data_frame.Devops_failed).sum()),
            "Devops_skipped": int((test_data_frame.Devops_skipped).sum()),
        }
        return test_stats

    @classmethod
    def get_keyword_statistics(self, kw_list):
        kw_data_frame = pd.DataFrame.from_records(kw_list)
        if not kw_data_frame.empty:
            kw_stats = {
                "Total" : (kw_data_frame.Status).count(),
                "Pass"  : (kw_data_frame.Status == 'PASS').sum(),
                "Fail"  : (kw_data_frame.Status == 'FAIL').sum(),
                "Skip"  : (kw_data_frame.Status == 'SKIP').sum()
            }
        else:
            kw_stats = {
                "Total" : 0,
                "Pass"  : 0,
                "Fail"  : 0,
                "Skip"  : 0,
            }
        return kw_stats
    
    def group_error_messages(self, test_list):
        test_data_frame = pd.DataFrame.from_records(test_list)
        return (test_data_frame.groupby("Message").agg(times = ("Status", "count")).head(6).reset_index()).sort_values(by = ['times'], ascending = [False], ignore_index=True)
    
    def suite_error_statistics(self, suite_list):
        suite_data_frame = pd.DataFrame.from_records(suite_list)
        required_data_frame = pd.DataFrame(suite_data_frame, columns = ['Name', 'Total', 'Fail'])
        required_data_frame['percent'] = (required_data_frame['Fail'] / required_data_frame['Total'])*100
        # print(required_data_frame)
        return required_data_frame.sort_values(by = ['Fail'], ascending = [False], ignore_index=True).head(10).reset_index()
